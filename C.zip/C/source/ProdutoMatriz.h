﻿#include <stdio.h>
#include <stdlib.h>

void Multiplica_matriz(int tamanho);